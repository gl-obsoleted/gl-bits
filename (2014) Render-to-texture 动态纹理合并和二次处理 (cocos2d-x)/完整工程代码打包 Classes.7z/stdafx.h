/*!
 * \file stdafx.h
 * \date 2014/07/25 16:47
 * \author Gu Lu (gulu@kingsoft.com)
 *
 * \brief Definition of stdafx 
*/

#pragma once

#include "cocos2d.h"

#include <vector>
#include <string>
