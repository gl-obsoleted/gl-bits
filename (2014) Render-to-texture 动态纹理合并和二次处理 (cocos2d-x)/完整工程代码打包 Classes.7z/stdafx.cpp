/*!
 * \file stdafx.cpp
 * \date 2014/07/25 16:47
 * \author Gu Lu (gulu@kingsoft.com)
 *
 * \brief Implementation of stdafx
*/

#include "stdafx.h"

